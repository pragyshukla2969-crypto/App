package com.uniconv
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var del: CheckBox
    private var apps = listOf<File>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        val pick = Button(this).apply { text = "Choose file to convert" }
        del = CheckBox(this).apply { text = "Delete original file after converting" }
        status = TextView(this).apply { text = "Pick any file. Type is auto-detected." }
        list = ListView(this)
        root.addView(pick); root.addView(del); root.addView(status)
        root.addView(TextView(this).apply { text = "Converted apps (tap to run):"; gravity = Gravity.START; setPadding(0, 24, 0, 8) })
        root.addView(list)
        setContentView(root)
        pick.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }, 1)
        }
        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(Intent(this, ViewerActivity::class.java).putExtra("dir", apps[i].absolutePath))
        }
        refresh()
    }

    private fun refresh() {
        apps = Converter.appsDir(this).listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: listOf()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, apps.map { it.name })
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri: Uri = data?.data ?: return
        if (req != 1 || res != RESULT_OK) return
        status.text = "Converting..."
        thread {
            val msg = try {
                val name = contentResolver.query(uri, null, null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "file"
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val (kind, _) = Converter.convert(this, name, bytes)
                var m = "Done: $name (detected: $kind)"
                if (del.isChecked) m += try {
                    if (DocumentsContract.deleteDocument(contentResolver, uri)) "\nOriginal deleted." else "\nCould not delete original."
                } catch (e: Exception) { "\nCould not delete original: ${e.message}" }
                m
            } catch (e: Exception) { "Failed: ${e.message}" }
            runOnUiThread { status.text = msg; refresh() }
        }
    }
}
