package com.uniconv
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

object Detector {
    fun zipNames(d: ByteArray): List<String> {
        val out = mutableListOf<String>()
        ZipInputStream(ByteArrayInputStream(d)).use { z ->
            while (true) { val e = z.nextEntry ?: break; out += e.name }
        }
        return out
    }
    fun detect(d: ByteArray, name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        fun starts(vararg b: Int) = d.size >= b.size && b.indices.all { d[it] == b[it].toByte() }
        if (starts(0x4D, 0x5A)) {                       // MZ -> PE
            return try {
                val bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
                val pe = bb.getInt(0x3C)
                when (bb.getShort(pe + 4).toInt() and 0xFFFF) {
                    0x14c -> "exe-x86"; 0x8664 -> "exe-x64"; 0xAA64 -> "exe-arm64"; else -> "exe-other"
                }
            } catch (e: Exception) { "exe-other" }
        }
        if (starts(0x7F, 0x45, 0x4C, 0x46)) return "elf"
        if (starts(0x50, 0x4B, 0x03, 0x04)) {
            val n = zipNames(d)
            return when {
                "AndroidManifest.xml" in n -> "apk"
                n.any { it.endsWith("index.html") } -> "webapp-zip"
                else -> "zip"
            }
        }
        if (starts(0x89, 0x50, 0x4E, 0x47) || starts(0xFF, 0xD8, 0xFF) || starts(0x47, 0x49, 0x46, 0x38)) return "image"
        if (starts(0x25, 0x50, 0x44, 0x46)) return "pdf"
        val head = String(d, 0, minOf(d.size, 2048), Charsets.UTF_8).trimStart().lowercase()
        if (head.startsWith("<!doctype html") || head.startsWith("<html") || ext in listOf("html", "htm")) return "html"
        if (ext in listOf("txt", "md", "py", "js", "json", "csv", "log", "kt", "java", "c", "cpp")) return "text"
        return "unknown"
    }
}
