package com.uniconv
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

object Converter {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun page(title: String, body: String) =
        "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<title>${esc(title)}</title><style>body{font-family:sans-serif;margin:8px}img{max-width:100%}pre{white-space:pre-wrap}</style>" +
        "</head><body>$body</body></html>"

    fun appsDir(ctx: Context) = File(ctx.filesDir, "apps").apply { mkdirs() }

    /** Converts [data] into a self-contained offline mini-app. Returns (detected kind, app dir). */
    fun convert(ctx: Context, name: String, data: ByteArray): Pair<String, File> {
        val kind = Detector.detect(data, name)
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(appsDir(ctx), safe).apply { deleteRecursively(); mkdirs() }
        var start = "index.html"
        when (kind) {
            "html" -> File(dir, "index.html").writeBytes(data)
            "webapp-zip" -> start = unzip(data, dir)
            "image" -> { File(dir, safe).writeBytes(data); File(dir, "index.html").writeText(page(name, "<img src='$safe'>")) }
            "text" -> File(dir, "index.html").writeText(page(name, "<pre>" + esc(String(data)) + "</pre>"))
            "pdf" -> renderPdf(ctx, data, dir, name)
            "exe-x86" -> {
                val arm = X86Translator.translate(X86Translator.peText(data))
                File(dir, "code.arm64").writeBytes(arm)
                val hex = arm.toList().chunked(4).joinToString("\n") { w -> w.reversed().joinToString("") { "%02x".format(it) } }
                File(dir, "index.html").writeText(page(name, "<h3>x86 -> ARM64</h3><p>${arm.size} bytes of ARM64 code (saved as code.arm64). Words:</p><pre>$hex</pre>"))
            }
            else -> { dir.deleteRecursively(); throw UnsupportedOperationException(
                when (kind) {
                    "exe-x64" -> "64-bit .exe: translator not built yet"
                    "apk" -> "Already an Android app (APK)"
                    else -> "No converter for type '$kind' yet"
                }) }
        }
        File(dir, ".start").writeText(start)
        return kind to dir
    }

    private fun unzip(data: ByteArray, dir: File): String {
        val root = dir.canonicalPath + File.separator
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val f = File(dir, e.name)
                if (!f.canonicalPath.startsWith(root)) continue          // zip-slip guard
                if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { z.copyTo(it) } }
            }
        }
        return dir.walkTopDown().filter { it.name == "index.html" }
            .minByOrNull { it.path.length }!!.relativeTo(dir).path
    }

    private fun renderPdf(ctx: Context, data: ByteArray, dir: File, name: String) {
        val tmp = File(ctx.cacheDir, "tmp.pdf").apply { writeBytes(data) }
        val pfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY)
        val sb = StringBuilder()
        PdfRenderer(pfd).use { r ->
            for (i in 0 until minOf(r.pageCount, 100)) r.openPage(i).use { p ->
                val w = 1080; val h = w * p.height / p.width
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                File(dir, "p$i.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                sb.append("<img src='p$i.png'><hr>")
            }
        }
        File(dir, "index.html").writeText(page(name, sb.toString()))
        tmp.delete()
    }
}
