package com.uniconv
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** x86 (32-bit subset) -> AArch64. eax..edi -> w0..w7. Unsupported opcodes throw. */
object X86Translator {
    private fun movz(rd: Int, imm: Int) = 0x52800000 or (imm shl 5) or rd
    private fun movkHi(rd: Int, imm: Int) = 0x72A00000 or (imm shl 5) or rd
    private fun orr(rd: Int, rm: Int) = 0x2A0003E0 or (rm shl 16) or rd
    private fun rrr(base: Int, rd: Int, rn: Int, rm: Int) = base or (rm shl 16) or (rn shl 5) or rd
    private const val RET = 0xD65F03C0.toInt()
    private const val NOP = 0xD503201F.toInt()
    private val ALU = mapOf(0x01 to 0x0B000000, 0x29 to 0x4B000000, 0x31 to 0x4A000000,
                            0x21 to 0x0A000000, 0x09 to 0x2A000000)

    fun peText(d: ByteArray): ByteArray {
        val bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val pe = bb.getInt(0x3C)
        val nsec = bb.getShort(pe + 6).toInt()
        val opt = bb.getShort(pe + 20).toInt() and 0xFFFF
        var s = pe + 24 + opt
        repeat(nsec) {
            val name = String(d, s, 8).trimEnd('\u0000')
            val vsize = bb.getInt(s + 8); val rsize = bb.getInt(s + 16); val roff = bb.getInt(s + 20)
            if (name == ".text") return d.copyOfRange(roff, roff + minOf(rsize, if (vsize > 0) vsize else rsize))
            s += 40
        }
        error(".text section not found")
    }

    fun translate(code0: ByteArray): ByteArray {
        var end = code0.size
        while (end > 0 && code0[end - 1] == 0.toByte()) end--
        val code = code0.copyOf(end)
        val words = ArrayList<Int>()
        var i = 0
        while (i < code.size) {
            val op = code[i].toInt() and 0xFF
            when {
                op in 0xB8..0xBF -> {
                    val imm = ByteBuffer.wrap(code, i + 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    words += movz(op - 0xB8, imm and 0xFFFF)
                    if ((imm ushr 16) != 0) words += movkHi(op - 0xB8, imm ushr 16)
                    i += 5
                }
                op == 0x89 || op == 0x8B || ALU.containsKey(op) -> {
                    val m = code[i + 1].toInt() and 0xFF
                    require(m shr 6 == 3) { "memory operand at 0x%x not supported yet".format(i) }
                    val reg = (m shr 3) and 7; val rm = m and 7
                    words += when (op) {
                        0x89 -> orr(rm, reg)
                        0x8B -> orr(reg, rm)
                        else -> rrr(ALU[op]!!, rm, rm, reg)
                    }
                    i += 2
                }
                op == 0xC3 -> { words += RET; i += 1 }
                op == 0x90 -> { words += NOP; i += 1 }
                else -> error("unsupported x86 opcode 0x%02x at offset 0x%x".format(op, i))
            }
        }
        val out = ByteArrayOutputStream()
        for (w in words) for (k in 0..3) out.write((w ushr (8 * k)) and 0xFF)
        return out.toByteArray()
    }
}
