package com.uniconv
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

/** Runs a converted app fully offline. */
class ViewerActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dir = File(intent.getStringExtra("dir")!!)
        val start = File(dir, ".start").readText()
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.allowFileAccess = true
        w.settings.blockNetworkLoads = true
        w.webViewClient = WebViewClient()
        setContentView(w)
        w.loadUrl("file://" + File(dir, start).absolutePath)
    }
}
